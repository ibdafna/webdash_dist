# Stub __init__.py for the sympy.functions.special package
