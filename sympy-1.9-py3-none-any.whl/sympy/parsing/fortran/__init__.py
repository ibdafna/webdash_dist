"""Used for translating Fortran source code into a SymPy expression. """
