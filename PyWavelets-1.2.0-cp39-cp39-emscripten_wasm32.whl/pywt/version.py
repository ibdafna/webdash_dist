
# THIS FILE IS GENERATED FROM PYWAVELETS SETUP.PY
short_version = '1.2.0'
version = '1.2.0'
full_version = '1.2.0'
git_revision = 'da62cc9829ad68a4c08b3e9adb327cfeb47d045d'
release = True

if not release:
    version = full_version
